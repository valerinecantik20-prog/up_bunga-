print("===== KASIR KANTIN KAMPUS =====")

total_belanja = 0

while True:
    nama = input("\nMasukkan nama makanan: ")
    harga = int(input("Masukkan harga makanan: Rp"))
    jumlah = int(input("Masukkan jumlah pembelian: "))

    total = harga * jumlah
    total_belanja += total

    print("Makanan:", nama)
    print("Total harga: Rp", total)

    lagi = input("\nTambah makanan lagi? (ya/tidak): ")

    if lagi.lower() != "ya":
        break

print("\n===== TOTAL PEMBAYARAN =====")
print("Total belanja: Rp", total_belanja)

if total_belanja > 100000:
    diskon = total_belanja * 10 / 100
else:
    diskon = 0

total_bayar = total_belanja - diskon

print("Diskon: Rp", diskon)
print("Total bayar: Rp", total_bayar)
print("============================")
print("Terima kasih sudah berbelanja!")
